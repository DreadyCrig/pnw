NSM Morphine - Changelog
========================

v2.0.4
------

* [fix] Addressed EE 2.8.0 issues

v2.0.3
------

* [enhancement] Added tab hiding to javascript for NSM addons

v2.0.2
------

* [enhancement] Added .badge style for accessories
* [fix] Added missing .scss source files

v2.0.1

* [enhancement] Updated scripts for EE v2.2.x compatibility

v2.0.0
------

* Complete rewrite of most styles
* Removed CP Tweaks. They now live in override.css
* Compressed JS for faster download

v1.0.0
------

* Initial release
